package com.example.zd2_2up

import android.app.Activity
import android.os.Bundle
import com.example.zd2_2up.databinding.ActivityListOfRecipesBinding

class ListOfRecipes : Activity() {

    private lateinit var binding: ActivityListOfRecipesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityListOfRecipesBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }
}