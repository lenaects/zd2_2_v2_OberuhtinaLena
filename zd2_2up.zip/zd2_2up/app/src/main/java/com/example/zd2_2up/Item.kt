package com.example.zd2_2up

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "items")

//коллоны
data class Item(

    //ид
    @PrimaryKey(autoGenerate = true)
    var id: Int? = null,
    @ColumnInfo(name = "title")
    var title : String,
    @ColumnInfo(name = "ingredients")
    var ingredients:String,
    @ColumnInfo(name = "readyInMinutes")
    var readyInMinutes:String

    )