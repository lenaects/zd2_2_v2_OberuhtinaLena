package com.example.zd2_2up

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.example.zd2_2up.databinding.ActivityScreenStatisticsBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.lifecycle.asLiveData
import kotlinx.coroutines.withContext

class ScreenStatistics : AppCompatActivity() {

    private lateinit var binding: ActivityScreenStatisticsBinding
    private val dataList = mutableListOf<Item>()
    private lateinit var buttonclear: Button
    private lateinit var buttonadd: Button
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)

        binding = ActivityScreenStatisticsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        printInfo()
        buttonclear=findViewById(R.id.butclear)
        buttonadd=findViewById(R.id.butadd)
        buttonclear.setOnClickListener { val db = MainDb.getDb(this)
            CoroutineScope(Dispatchers.IO).launch {
                // Очистить все таблицы в базе данных
                db.clearAllTables()
                withContext(Dispatchers.Main) {
                }
            }
            printInfo() }
        buttonadd.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Введите данные")

            // Создайте контейнер LinearLayout для размещения двух EditText
            val layout = LinearLayout(this)
            layout.orientation = LinearLayout.VERTICAL

            // Создайте два EditText для ввода данных
            val EditTitle = EditText(this)
            val EditIngredient = EditText(this)
            val EditReady = EditText(this)

            // Установите хинты для EditText
            EditTitle.hint = "Введите название рецепта"
            EditIngredient.hint = "Введите ингридиенты"
            EditReady.hint = "Введите время приготовления"

            // Добавьте EditText к контейнеру
            layout.addView(EditTitle)
            layout.addView(EditIngredient)
            layout.addView(EditReady)

            builder.setView(layout)

            // Установите кнопку "OK" для сохранения данных
            builder.setPositiveButton("OK") { dialog, _ ->
                val title = EditTitle.text.toString()
                val ingredient = EditIngredient.text.toString()
                val ready=EditReady.text.toString()
                // Здесь можно обработать введенные данные (value1 и value2)
                //запись в бд
                if(title.length == 0 || ingredient.length == 0||ready.length==0){
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Не сохранено")
                        .setMessage("Необходимо заполнить все поля")
                        .setPositiveButton("ОК") {
                                dialog, id ->  dialog.cancel()
                        }
                    builder.create()
                }
                else{
                    //сама запись
                    val db = MainDb.getDb(this)
                    val item = Item(null, title,ingredient,ready)
                    Thread{
                        db.getDao().insertItem(item)
                    }.start()
                    dialog.dismiss()
                    printInfo()
                }

            }

            // Установите кнопку "Отмена" для закрытия диалога
            builder.setNegativeButton("Отмена") { dialog, _ ->
                dialog.cancel()
            }

            val dialog = builder.create()
            dialog.show()
        }

    }
    private fun printInfo() {
        val textList = findViewById<ListView>(R.id.listView)
        dataList.clear()
        val db = MainDb.getDb(this)
        db.getDao().getAllItem().asLiveData().observe(this) { list ->
            val updatedDataList = mutableListOf<Item>()
            list.forEach { item ->

                val newItem = Item(id = item.id, title = item.title, readyInMinutes = item.readyInMinutes, ingredients = item.ingredients)
                updatedDataList.add(newItem)
            }
            // После завершения цикла, обновите dataList
            dataList.clear()
            dataList.addAll(updatedDataList)
            val itemAdapter = ItemAdapter(this, dataList,
                onDeleteClick = { itemToDelete ->
                    // Здесь выполняйте удаление элемента из базы данных и обновление списка
                    val db = MainDb.getDb(this)
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            db.getDao().deleteItem(itemToDelete)

                            printInfo()
                        } catch (e: Exception) {
                        }
                    }
                    printInfo()
                    printInfo()
                },
                onEditClick = { position ->
                    val db = MainDb.getDb(this)
                    var bdNewText: Array<String> = arrayOf("id", "title", "readyInMinutes", "ingredients")
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            bdNewText= arrayOf(position.id.toString(), position.title, position.ingredients, position.readyInMinutes)
                        } catch (e: Exception) {
                        }
                    }
                    //изменения через AlertDiolog
                    val builder = AlertDialog.Builder(this)
                    builder.setTitle("Измените данные")
                    // Создайте контейнер LinearLayout для размещения EditText
                    val layout = LinearLayout(this)
                    layout.orientation = LinearLayout.VERTICAL
                    val EditTitle = EditText(this)
                    val EditIngredients = EditText(this)
                    val EditReadyInMinutes = EditText(this)
                    EditTitle.hint = "Введите название рецепта"
                    EditReadyInMinutes.hint = "Введите время приготовления"
                    EditIngredients.hint = "Введите ингридиенты"
                    EditTitle.setText(bdNewText[1])
                    EditReadyInMinutes.setText(bdNewText[3])
                    EditIngredients.setText(bdNewText[2])
                    layout.addView(EditTitle)
                    layout.addView(EditReadyInMinutes)
                    layout.addView(EditIngredients)
                    builder.setView(layout)
                    builder.setPositiveButton("OK") { dialog, _ ->
                        var title = EditTitle.text.toString()
                        var readyInMinutes = EditReadyInMinutes.text.toString()
                        var ingredients = EditIngredients.text.toString()

                        //запись в бд
                        //проверка
                        if(title.isEmpty()){
                            title= bdNewText[1];
                        }
                        if(readyInMinutes.isEmpty()){
                            readyInMinutes = bdNewText[3];
                        }
                        if(ingredients.isEmpty()){
                            ingredients = bdNewText[2];
                        }
                        val item = Item(bdNewText[0].toInt(), title,  ingredients,readyInMinutes)
                        CoroutineScope(Dispatchers.IO).launch {
                            db.getDao().updateItem(item)
                        }
                        printInfo()
                    }
                    builder.setNegativeButton("Отмена") { dialog, _ ->
                        dialog.cancel()
                    }

                    val dialog = builder.create()
                    dialog.show()
                    printInfo()

                })
            textList.adapter = itemAdapter
            itemAdapter.notifyDataSetChanged()

        }
    }
}