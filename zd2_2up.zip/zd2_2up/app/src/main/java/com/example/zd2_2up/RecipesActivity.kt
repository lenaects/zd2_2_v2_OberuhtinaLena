package com.example.zd2_2up

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.zd2_2up.databinding.ActivityRecipesBinding

import okhttp3.Response
import okhttp3.*
import org.json.JSONException
import org.json.JSONObject

class RecipesActivity : Activity() {

    private lateinit var binding: ActivityRecipesBinding
    private lateinit var editText: EditText
    private lateinit var button: Button
    private lateinit var perhod:Button
    private lateinit var resultTextView: TextView
    //private val BASE_URL = "https://api.spoonacular.com/recipes/"
    private val API_KEY = "12939f360bff4fef8800f479ecd5b7aa"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityRecipesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        editText = findViewById(R.id.editText)
        button=findViewById(R.id.button)
        resultTextView= findViewById(R.id.resultTextView)
        perhod=findViewById(R.id.butperehod)
        button.setOnClickListener {
            val recipeId = editText.text.toString()
            getResualt(recipeId)
        }
        perhod.setOnClickListener { val intent = Intent(this, ScreenStatistics::class.java)
            startActivity(intent) }
    }
    /*private fun fetchRecipeInfo(recipeId: String) {
        val url = "$BASE_URL$recipeId/information?apiKey=$API_KEY"
        FetchRecipeTask(resultTextView).execute(url)
    }*/
    private fun getResualt(recipeId:String){
        if (recipeId.isNotEmpty()) {
            val url = "https://api.spoonacular.com/recipes/$recipeId/information?apiKey=$API_KEY"

            val queue = Volley.newRequestQueue(this)
            val stringRequest = StringRequest(
                Request.Method.GET, url,
                { response ->
                    try {
                        val jsonObject = JSONObject(response)
                        val title = jsonObject.getString("title")
                        val readyInMinutes = jsonObject.getInt("readyInMinutes")
                        val extendedIngredients = jsonObject.getJSONArray("extendedIngredients")
                        val ingredients = StringBuilder()
                        for (i in 0 until extendedIngredients.length()) {
                            val ingredientObject = extendedIngredients.getJSONObject(i)
                            val ingredient = ingredientObject.getString("original")
                            ingredients.append(ingredient).append("\n")
                        }
                        Log.d("MyLog", "Title: $title")
                        Log.d("MyLog", "Ingredients: $ingredients")
                        Log.d("MyLog", "Ready in minutes: $readyInMinutes")

                        val resultText = "Recipe: $title\n\nIngredients:\n$ingredients\n\nReady in $readyInMinutes minutes"
                        resultTextView.text = resultText
                        //запись в бд
                        val db = MainDb.getDb(this)
                        val item = Item(
                            null,
                            title,
                            readyInMinutes.toString(),
                            ingredients.toString(),
                        )
                        Thread {
                            db.getDao().insertItem(item)
                        }.start()

                    } catch (e: JSONException) {
                        Log.e("MyLog", "JSON Parsing error: ${e.message}")
                    }
                },
                { error ->
                    Log.d("MyLog", "Volley error: ${error.message}")
                })

            queue.add(stringRequest)
        }
            else{ Toast.makeText(this@RecipesActivity, "Заполните поле", Toast.LENGTH_SHORT).show()
            }
        }

    }


